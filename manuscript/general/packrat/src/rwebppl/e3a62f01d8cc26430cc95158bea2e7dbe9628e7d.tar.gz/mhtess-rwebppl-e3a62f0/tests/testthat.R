library(testthat)
library(rwebppl)

test_check("rwebppl")
