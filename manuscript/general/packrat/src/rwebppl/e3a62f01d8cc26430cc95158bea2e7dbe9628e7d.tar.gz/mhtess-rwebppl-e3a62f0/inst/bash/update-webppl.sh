#!/bin/bash

RWEBPPL=$1

cd $RWEBPPL/js

npm update --save webppl
