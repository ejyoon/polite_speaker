## Test environments
* local OS X install, R 3.2.3
* ubuntu 12.04 (on travis-ci), R 3.3.0

## R CMD check results
There were no ERRORs or WARNINGs.